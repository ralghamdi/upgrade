ALTER TABLE `q_main_base`.`subcategories` CHANGE COLUMN `categoryID` `categoryID` INT(11) NULL DEFAULT '1' ;



CREATE TABLE `templates` (
  `db_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) DEFAULT 'New Template',
  `db_title` varchar(500) DEFAULT 'New Title',
  `db_type_id` int(11) DEFAULT '0',
  `db_category_id` int(11) DEFAULT '1',
  `db_sub_category_id` int(11) DEFAULT '1',
  `db_severity` varchar(45) DEFAULT 'Low',
  `db_standard` varchar(100) DEFAULT 'NIST',
  `db_assignee_id` int(11) DEFAULT '0',
  `db_notification_groups` longtext,
  `db_impacted_asset` varchar(100) DEFAULT 'Other',
  `db_sla_id` int(11) DEFAULT '0',
  `db_module` varchar(45) DEFAULT NULL,
  `db_del` varchar(5) DEFAULT 'No',
  `db_use_case_id` int(11) DEFAULT '0',
  `db_use_case_source_type` varchar(100) DEFAULT 'Other',
  `db_use_case_source_name` varchar(100) DEFAULT 'N/A',
  `db_entry_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
 
 
ALTER TABLE `q_main_base`.`event_rules` 
CHANGE COLUMN `db_cat_id` `db_cat_id` INT(11) NULL DEFAULT 1 ,
CHANGE COLUMN `db_sub_cat_id` `db_sub_cat_id` INT(11) NULL DEFAULT 1 ;



INSERT INTO `q_main_base`.`mitre_tactics` (`db_id`, `db_name`, `db_description`, `db_type`, `db_last_update`) VALUES ('TA0043', 'Reconnaissance', 'The adversary is trying to gather information they can use to plan future operations.', 'Enterprise', '2019-10-10 23:08:01');
INSERT INTO `q_main_base`.`mitre_tactics` (`db_id`, `db_name`, `db_description`, `db_type`, `db_last_update`) VALUES ('TA0042', 'Resource Development\n', 'The adversary is trying to establish resources they can use to support operations.', 'Enterprise', '2019-10-10 23:08:01');
 

ALTER TABLE `q_main_base`.`api` ADD COLUMN `db_enabled` VARCHAR(3) NULL DEFAULT 'No';



ALTER TABLE `q_main_base`.`orchestrator_jobs` CHANGE COLUMN `db_Job_API_URL` `db_Job_API_URL` LONGTEXT NULL DEFAULT NULL AFTER `db_Job_Tilte`;

ALTER TABLE `q_main_base`.`orchestrator_jobs` 
ADD COLUMN `db_group` VARCHAR(100) NULL DEFAULT 'SOAR' AFTER `db_Job_API_URL_Response_Output`,
ADD COLUMN `db_user_soar` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_group`;

ALTER TABLE `q_main_base`.`orchestrator_jobs` 
CHANGE COLUMN `db_group` `db_group` VARCHAR(100) NULL DEFAULT NULL AFTER `db_Job_Tilte`,
CHANGE COLUMN `db_user_soar` `db_user_soar` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_group`;


UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Public_Form', 'db_Display_Text' = 'AUTHENTICATION ENABLED' WHERE (`db_name` = 'PUBLIC_FORM_AUTHENTICATION_ENABLED');
UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Public_Form', 'db_Display_Text' = 'AUTHENTICATION TYPE' WHERE (`db_name` = 'PUBLIC_FORM_AUTHENTICATION_TYPE');


INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('304', 'PUBLIC_FORM_OBJECT_TYPE', 'Public_Form', 'OBJECT TYPE', 'Yes', 'Incident', 'Case', 'Cyber Threat', 'Cyber Threat', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('305', 'PUBLIC_FORM_OBJECT_CATEGORY', 'Public_Form', 'OBJECT CATEGORY', 'Yes', 'User Activity', 'User Activity', 'User Activity', 'User Activity', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('306', 'PUBLIC_FORM_OBJECT_SUB_CATEGORY', 'Public_Form', 'OBJECT SUB CATEGORY', 'Yes', 'Direct Reported Cases', 'Direct Reported Cases', 'Direct Reported Cases', 'Direct Reported Cases', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');


ALTER TABLE `q_main_base`.`tasks` 
ADD COLUMN `db_SOAR_Task` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_Resolve_SLA_Warning_Email_Sent`,
ADD COLUMN `db_SOAR_Job` VARCHAR(500) NULL DEFAULT 'N/A' AFTER `db_SOAR_Task`,
ADD COLUMN `db_SOAR_Output` LONGTEXT NULL AFTER `db_SOAR_Job`;

ALTER TABLE `q_main_base`.`reports` ADD COLUMN `db_title` VARCHAR(500) NULL AFTER `db_module`;
 
 

ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_Job_Notification_Emails` LONGTEXT NULL DEFAULT NULL;

ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_Job_Containment_Phase_ID` INT(11) NULL DEFAULT 1 AFTER `db_Job_Notification_Emails`;

ALTER TABLE `q_main_base`.`tasks` ADD COLUMN `db_SOAR_Input` LONGTEXT NULL AFTER `db_SOAR_Output`;

INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('300', 'ORCHESTRATOR_SANDBOX_SERVICE_SAMA_SENDER', 'Email_Sandbox', 'SAMA ALERTS - SENDER ID', 'Yes', 'thamir@qss.com.sa', 'thamir@qss.com.sa', 'thamir@qss.com.sa', 'thamir@qss.com.sa', '2021-12-05 22:51:29', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('301', 'ORCHESTRATOR_SANDBOX_SERVICE_SAMA_CONTENT_TYPE', 'Email_Sandbox', 'SAMA ALERTS - EMAIL FORMAT', 'Yes', 'text/plain', 'text/plain', 'text/plain', 'text/plain', '2021-12-06 14:24:44', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('302', 'ORCHESTRATOR_SANDBOX_SERVICE_NCA_SENDER', 'Email_Sandbox', 'NCA ALERTS - SENDER ID', 'Yes', 'thamir@qss.com.sa', 'mohamed.kanzi@qss.com.sa', 'thamir@qss.com.sa', 'thamir@qss.com.sa', '2021-09-03 01:42:20', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('303', 'ORCHESTRATOR_SANDBOX_SERVICE_NCA_CONTENT_TYPE', 'Email_Sandbox', 'NCA ALERTS - EMAIL FORMAT', 'Yes', 'text/plain', 'text/plain', 'text/plain', 'text/plain', '2020-06-20 14:09:34', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('304', 'PUBLIC_FORM_OBJECT_TYPE', 'Public_Form', 'OBJECT TYPE', 'Yes', 'Incident', 'Case', 'Cyber Threat', 'Cyber Threat', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('305', 'PUBLIC_FORM_OBJECT_CATEGORY', 'Public_Form', 'OBJECT CATEGORY', 'Yes', 'User Activity', 'User Activity', 'User Activity', 'User Activity', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_Share`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('306', 'PUBLIC_FORM_OBJECT_SUB_CATEGORY', 'Public_Form', 'OBJECT SUB CATEGORY', 'Yes', 'Direct Reported Cases', 'Direct Reported Cases', 'Direct Reported Cases', 'Direct Reported Cases', '2021-12-12 13:47:21', 'No', 'simp scmp stmp', 'String', '', 'Boolean', '0');

ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_Job_Applied_IOC_Type` VARCHAR(1000) NULL DEFAULT NULL ;




INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_ID`, `db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`) VALUES ('8', 'SAMA Check Alerts', 'SOAR', 'No', 'http://127.0.0.1:8080/scmp/api/rest/sama/read_alerts/v1/type=Case|assignee=soc_coordinator|initiator=soar|notification=yes|iocs_cti_check=no|cat=User Activity|subcat=Direct Reported Cases', '60', 'Ready', '2020-10-13 13:57:58', '0', '0', '0', '0', 'Yes', '', '1');
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_ID`, `db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`) VALUES ('9', 'NCA Check Alerts', 'SOAR', 'No', 'http://127.0.0.1:8080/simp/api/rest/nca/read_alerts/v1/type=Case|assignee=soc_coordinator|initiator=soar|notification=yes|iocs_cti_check=no|cat=User Activity|subcat=Direct Reported Cases', '60', 'Ready', '2020-10-13 13:57:58', '0', '0', '0', '0', 'Yes', '', '1');




ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_allowed_module` VARCHAR(500) NULL DEFAULT '-' AFTER `db_Job_Containment_Phase_ID`;
ALTER TABLE `q_main_base`.`orchestrator_jobs` ADD COLUMN `db_Intell_Base_Domain` LONGTEXT NULL AFTER `db_allowed_module`;

INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_ID`, `db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`) VALUES ('10', 'Add Observable (FW)', 'Anomali', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/anomali/add/observal/v1?tags=Fw,STMP,Q-SOAR', '0', 'Ready', '2020-10-13 13:57:58', '0', '0', '0', '0', 'Yes', 'IP|IP Src|IP Dst', '10', 'stmp', 'https://api.threatstream.com');
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_ID`, `db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`) VALUES ('11', 'Add Observable (PX)', 'Anomali', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/anomali/add/observal/v1?tags=Proxy,STMP,Q-SOAR', '0', 'Ready', '2020-10-13 13:57:58', '0', '0', '0', '0', 'Yes', 'Domain', '10', 'stmp', 'https://api.threatstream.com');


ALTER TABLE `q_main_base`.`system_properties`  CHANGE COLUMN `db_Value_Share` `db_Value_CTSP` LONGTEXT NULL DEFAULT NULL ;

ALTER TABLE `q_main_base`.`users` ADD COLUMN `db_ctsp` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_stmp`;

ALTER TABLE `q_main_base`.`system_settings` ADD COLUMN `db_CTSP` VARCHAR(500) NULL DEFAULT NULL AFTER `db_SCMP`;

update system_settings set db_ctsp = db_scmp;

 

INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('307', 'CUSTOM_FIELDS_INCIDENT_SUMMARY', 'CUSTOM_FIELDS', 'INCIDENT SUMMARY', 'Yes', 'No', 'No', 'No', 'No', '2021-12-25 14:20:55', 'null', 'No', 'simp scmp stmp ctsp', 'List', 'Yes|No', 'Boolean', '0');
ALTER TABLE `q_main_base`.`incidents` ADD COLUMN `db_Incident_Summary` LONGTEXT NULL;
ALTER TABLE `q_main_base`.`incident_ioc` ADD COLUMN `db_Threat_Intell_Source_ID_Kazbot` VARCHAR(500) NULL DEFAULT '-';

INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_ID`, `db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`) VALUES ('14', 'AnyRun Check Jobs', 'SOAR', 'No', 'http://127.0.0.1:8080/scmp/api/rest/sandbox/anyrun/check/v1?api_key=LBcz3kNyYF6k45d23hYw7ihFeKhPfMizvnBCfQtR&base_url=https://api.any.run/v1/analysis', '3600', 'Ready', '2020-10-13 13:57:58', '0', '0', '0', '0', 'Yes', '', '1', '-');

 


ALTER TABLE `q_main_base`.`incidents` 
ADD COLUMN `db_Shift_Closed` VARCHAR(45) NULL DEFAULT '-' AFTER `db_Incident_Summary`,
ADD COLUMN `db_Shift_RTC` VARCHAR(45) NULL DEFAULT '-' AFTER `db_Shift_Closed`,
ADD COLUMN `db_Shift_Escalated` VARCHAR(45) NULL DEFAULT '-' AFTER `db_Shift_RTC`;

INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('308', 'ENABLE_SHIFT_TRACKING', 'Workflow', 'ENABLE SHIFT TRACKING', 'Yes', 'No', 'Yes', 'No', 'No', '2022-01-04 14:04:37', 'null', 'No', 'scmp', 'List', 'Yes|No', 'Boolean', '0');

UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Deprecated' WHERE (`db_name` = 'ORCHESTRATOR_SANDBOX_SERVICE_SAMA_SENDER');
UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Deprecated' WHERE (`db_name` = 'ORCHESTRATOR_SANDBOX_SERVICE_SAMA_CONTENT_TYPE');
UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Deprecated' WHERE (`db_name` = 'ORCHESTRATOR_SANDBOX_SERVICE_NCA_SENDER');
UPDATE `q_main_base`.`system_properties` SET `db_Group` = 'Deprecated' WHERE (`db_name` = 'ORCHESTRATOR_SANDBOX_SERVICE_NCA_CONTENT_TYPE');


ALTER TABLE `q_main_base`.`handover` ADD COLUMN `db_Acknowledged` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_RTC_Cases`;
 

INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('309', 'RECORDED_FUTURE_RULES_MAPPING', 'API_Settings', 'RECORDED FUTURE RULES MAPPING', 'Yes', '', 'Leaked Email Monitoring;Case;User Activity;Direct Reported Cases|Company Email on Code Repository;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities New Exploit Chatter;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Linked to Pentest Tools;Case;User Activity;Direct Reported Cases|Vulnerability Risk, New Critical or Pre NVD Watch List Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Recently Linked to Malware;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vendors & Products Mentioned with Vulnerabilities;Case;User Activity;Direct Reported Cases|Trends, Vulnerabilities;Case;User Activity;Direct Reported Cases|Possible Fraud related to COVID-19;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (Social Media);Case;User Activity;Direct Reported Cases|COVID-19 Suspicious Domain Registrations;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (non-Social Media);Case;User Activity;Direct Reported Cases|Banking and Payments, Banking Trojans, ATM Malware, Exploit Kits Malware;Case;User Activity;Direct Reported Cases|SABB Industry Risk - Trending Industry Peers;Case;User Activity;Direct Reported Cases|Banking and Payments, Vulnerabilities Recently Related to Banking & Payments;Case;User Activity;Direct Reported Cases|SABB Credit Card Monitoring;Case;User Activity;Direct Reported Cases|SABB Mentions of Service Disruptions;Case;User Activity;Direct Reported Cases|SABB Leaked Credential Monitoring;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--IP Address Mentions;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - IPs;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Brand Names;Case;User Activity;Direct Reported Cases|Cyber Attack Tragetting Banks in Middle East;Case;User Activity;Direct Reported Cases|SABB Brand Monitoring (Domains on Social Media);Case;User Activity;Direct Reported Cases|Analyst Notes on Regional Threats;Case;User Activity;Direct Reported Cases|Deactivated-SABB Identify Similar Domains;Case;User Activity;Direct Reported Cases|SABB Tech Stack Proof-of-concept Exploit;Case;User Activity;Direct Reported Cases|COVID-19 Domains Reported as SPAM;Case;User Activity;Direct Reported Cases|MITRE ATT&CK Identifier & Threat Actors;Case;User Activity;Direct Reported Cases|Saudi British Bank - Alawwal Bank Merge;Case;User Activity;Direct Reported Cases|COVID-19 Insikt Group Reporting;Case;User Activity;Direct Reported Cases|Insikt Notes related to Industry;Case;User Activity;Direct Reported Cases|SABB Cyber Threats to Brand;Case;User Activity;Direct Reported Cases|Suppliers affected by COVID-19;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--Domains on Non-Mainstream Sources;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--Brand Mentions on Non-Mainstream Sources;Case;User Activity;Direct Reported Cases|SABB Brand Mentions with Cyber entities;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Potential Typosquatting;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Brand Names;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - IPs;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--IP Address Mentions;Case;User Activity;Direct Reported Cases|SABB Leaked Credential Monitoring;Case;User Activity;Direct Reported Cases|SABB Mentions of Service Disruptions;Case;User Activity;Direct Reported Cases|SABB Credit Card Monitoring;Case;User Activity;Direct Reported Cases|Banking and Payments, Vulnerabilities Recently Related to Banking & Payments;Case;User Activity;Direct Reported Cases|SABB Industry Risk - Trending Industry Peers;Case;User Activity;Direct Reported Cases|Banking and Payments, Banking Trojans, ATM Malware, Exploit Kits Malware;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (non-Social Media);Case;User Activity;Direct Reported Cases|COVID-19 Suspicious Domain Registrations;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (Social Media);Case;User Activity;Direct Reported Cases|Possible Fraud related to COVID-19;Case;User Activity;Direct Reported Cases|Trends, Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vendors & Products Mentioned with Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Recently Linked to Malware;Case;User Activity;Direct Reported Cases|Vulnerability Risk, New Critical or Pre NVD Watch List Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Linked to Pentest Tools;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities New Exploit Chatter;Case;User Activity;Direct Reported Cases|Company Email on Code Repository;Case;User Activity;Direct Reported Cases|Leaked Email Monitoring;Case;User Activity;Direct Reported Cases', 'Leaked Email Monitoring;Case;User Activity;Direct Reported Cases|Company Email on Code Repository;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities New Exploit Chatter;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Linked to Pentest Tools;Case;User Activity;Direct Reported Cases|Vulnerability Risk, New Critical or Pre NVD Watch List Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Recently Linked to Malware;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vendors & Products Mentioned with Vulnerabilities;Case;User Activity;Direct Reported Cases|Trends, Vulnerabilities;Case;User Activity;Direct Reported Cases|Possible Fraud related to COVID-19;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (Social Media);Case;User Activity;Direct Reported Cases|COVID-19 Suspicious Domain Registrations;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (non-Social Media);Case;User Activity;Direct Reported Cases|Banking and Payments, Banking Trojans, ATM Malware, Exploit Kits Malware;Case;User Activity;Direct Reported Cases|SABB Industry Risk - Trending Industry Peers;Case;User Activity;Direct Reported Cases|Banking and Payments, Vulnerabilities Recently Related to Banking & Payments;Case;User Activity;Direct Reported Cases|SABB Credit Card Monitoring;Case;User Activity;Direct Reported Cases|SABB Mentions of Service Disruptions;Case;User Activity;Direct Reported Cases|SABB Leaked Credential Monitoring;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--IP Address Mentions;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - IPs;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Brand Names;Case;User Activity;Direct Reported Cases|Cyber Attack Tragetting Banks in Middle East;Case;User Activity;Direct Reported Cases|SABB Brand Monitoring (Domains on Social Media);Case;User Activity;Direct Reported Cases|Analyst Notes on Regional Threats;Cyber Threat;Cyber News;Anomali News|Deactivated-SABB Identify Similar Domains;Case;User Activity;Direct Reported Cases|SABB Tech Stack Proof-of-concept Exploit;Case;User Activity;Direct Reported Cases|COVID-19 Domains Reported as SPAM;Case;User Activity;Direct Reported Cases|MITRE ATT&CK Identifier & Threat Actors;Case;User Activity;Direct Reported Cases|Saudi British Bank - Alawwal Bank Merge;Case;User Activity;Direct Reported Cases|COVID-19 Insikt Group Reporting;Case;User Activity;Direct Reported Cases|Insikt Notes related to Industry;Case;User Activity;Direct Reported Cases|SABB Cyber Threats to Brand;Case;User Activity;Direct Reported Cases|Suppliers affected by COVID-19;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--Domains on Non-Mainstream Sources;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--Brand Mentions on Non-Mainstream Sources;Case;User Activity;Direct Reported Cases|SABB Brand Mentions with Cyber entities;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Potential Typosquatting;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - Brand Names;Case;User Activity;Direct Reported Cases|SABB Infrastructure and Brand Risk - IPs;Case;User Activity;Direct Reported Cases|SABB Infrastructure Monitoring--IP Address Mentions;Case;User Activity;Direct Reported Cases|SABB Leaked Credential Monitoring;Case;User Activity;Direct Reported Cases|SABB Mentions of Service Disruptions;Case;User Activity;Direct Reported Cases|SABB Credit Card Monitoring;Case;User Activity;Direct Reported Cases|Banking and Payments, Vulnerabilities Recently Related to Banking & Payments;Case;User Activity;Direct Reported Cases|SABB Industry Risk - Trending Industry Peers;Case;User Activity;Direct Reported Cases|Banking and Payments, Banking Trojans, ATM Malware, Exploit Kits Malware;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (non-Social Media);Case;User Activity;Direct Reported Cases|COVID-19 Suspicious Domain Registrations;Case;User Activity;Direct Reported Cases|COVID-19 linked Cyber Attacks (Social Media);Case;User Activity;Direct Reported Cases|Possible Fraud related to COVID-19;Case;User Activity;Direct Reported Cases|Trends, Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vendors & Products Mentioned with Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Recently Linked to Malware;Case;User Activity;Direct Reported Cases|Vulnerability Risk, New Critical or Pre NVD Watch List Vulnerabilities;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities Linked to Pentest Tools;Case;User Activity;Direct Reported Cases|Vulnerability Risk, Watch List Vulnerabilities New Exploit Chatter;Case;User Activity;Direct Reported Cases|Company Email on Code Repository;Case;User Activity;Direct Reported Cases|Leaked Email Monitoring;Case;User Activity;Direct Reported Cases', '', '2022-01-29 02:18:52', 'No', 'simp scmp stmp ctsp', 'FreeList', '', 'Boolean', '0');


ALTER TABLE `q_main_base`.`templates` ADD COLUMN `db_description` LONGTEXT NULL;


ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Description` `db_Description` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Notes` `db_Notes` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Lessons_Learnt` `db_Lessons_Learnt` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_RootCause` `db_RootCause` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Findings` `db_Findings` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Recommendations` `db_Recommendations` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Location` `db_Location` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_HR_Feedback` `db_HR_Feedback` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Violation` `db_Violation` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_TakenActionsSummary` `db_TakenActionsSummary` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Investigation_Summary` `db_Investigation_Summary` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
ALTER TABLE `q_main_base`.`incidents` CHANGE COLUMN `db_Conclusion` `db_Conclusion` LONGTEXT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci' NULL DEFAULT NULL ;
 
 

ALTER TABLE `q_main_base`.`orchestrator_jobs` CHANGE COLUMN `db_Job_First_Time_Run` `db_Job_First_Time_Run` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `q_main_base`.`orchestrator_jobs` CHANGE COLUMN `db_Job_Last_Time_Run` `db_Job_Last_Time_Run` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ;
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('Contain Host', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/contain/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=iaalzaid_API&user_password=Summer@123', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'Host Name', '10', 'stmp scmp', 'https://api.threatstream.com', 'assets');
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('Uncontain Host', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/uncontain/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=iaalzaid_API&user_password=Summer@123', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'Host Name', '10', 'stmp scmp', 'https://api.threatstream.com', 'assets');


ALTER TABLE `q_main_base`.`sandbox` ADD COLUMN `db_soar_response_message` LONGTEXT NULL AFTER `db_soar_response`;


INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('310', 'DEFAULT_ESCALATION_OBJECT', 'Workflow', 'DEFAULT ESCALATION OBJECT', 'Yes', 'Incident', 'Incident', 'Incident', 'Incident', '2022-01-10 10:47:35', 'Please add DisplayName_2 value from Types table', 'No', 'scmp stmp simp ctsp', 'String', '', 'Single', '2');



INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('Add IOCs', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/add_condition/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=cdcapi&user_password=Spring@123&indicator_category=SIMP&indicator_name=Test_API_Rule', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'IP|IP Src|IP Dst|Hash MD5|File Name|Domain|URL', '8', 'stmp scmp', 'https://api.threatstream.com', 'iocs');
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('Delete IOCs', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/delete_condition/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=cdcapi&user_password=Spring@123&indicator_category=SIMP&indicator_name=Test_API_Rule', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'IP|IP Src|IP Dst|Hash MD5|File Name|Domain|URL', '8', 'stmp scmp', 'https://api.threatstream.com', 'iocs');



ALTER TABLE `q_main_base`.`playbook` ADD COLUMN `db_use_case_id` INT(11) NULL DEFAULT '1' AFTER `db_sub_cat_id`;


 

INSERT INTO `q_main_base`.`lists` (`db_Value`, `db_Group`, `db_SubGroup`, `db_Del`, `db_EntryDate`) VALUES ('Registry Value', 'IOC', 'Host', 'No', '2019-07-18 22:18:49');
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Containment_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('Enterprise Search', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/search/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=cdcapi&user_password=Spring@123&all_host_set_id=1176', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'Registry Value|Registry Key|IP|IP Src|IP Dst|Domain|Hash MD5|Hash SHA1|Hash SHA256|File Name|URL|Process|User Name|Port|File Path', '9', 'stmp scmp simp', 'https://api.threatstream.com', 'iocs');
ALTER TABLE `q_main_base`.`orchestrator_jobs` CHANGE COLUMN `db_Job_Containment_Phase_ID` `db_Job_Standard_Phase_ID` INT(11) NULL DEFAULT '1' ;
INSERT INTO `q_main_base`.`orchestrator_jobs` (`db_Job_Tilte`, `db_group`, `db_user_soar`, `db_Job_API_URL`, `db_Job_Frequency_sec`, `db_Job_Current_Status`, `db_Job_First_Time_Run`, `db_Job_Last_Time_Run`, `db_Job_Last_Time_Run_Length`, `db_Job_Total_Run_Count`, `db_Job_Total_Run_Count_Success`, `db_Job_Total_Run_Count_Failure`, `db_Job_Enabled`, `db_Job_Applied_IOC_Type`, `db_Job_Standard_Phase_ID`, `db_allowed_module`, `db_Intell_Base_Domain`, `db_allowed_view`) VALUES ('System Info', 'FE-HX', 'Yes', 'http://127.0.0.1:8080/scmp/api/rest/fireeye/hx/system_info/v1/?base_url=https://10.20.25.207:3000/hx/api/v3&user_id=cdcapi&user_password=Spring@123', '0', 'Ready', '2020-10-13 13:57:58', '2022-02-05 00:36:02', '0', '0', '0', '0', 'Yes', 'IP|IP Src|IP Dst|Host Name', '9', 'stmp scmp simp', 'https://api.threatstream.com', 'assets');



ALTER TABLE `q_main_base`.`users` ADD COLUMN `db_ciso` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_ctsp`;


ALTER TABLE `q_main_base`.`system_properties` ADD COLUMN `db_Value_CISO` LONGTEXT NULL AFTER `db_Value_CTSP`;
UPDATE q_main_base.system_properties SET db_Value_CISO = db_Value_SIMP;
UPDATE `q_main_base`.`system_properties` SET `db_Value_CISO` = 'CISO Notification <no-reply@qss.com.sa>' WHERE (`db_Name` = 'NOTIFICATION_EMAIL_ACCOUNT');
UPDATE `q_main_base`.`system_properties` SET `db_Value_CISO` = 'CISO Security Analytics Platform' WHERE (`db_Name` = 'PRODUCT_NAME');
UPDATE `q_main_base`.`system_properties` SET `db_Value_CISO` = 'CISO' WHERE (`db_Name` = 'PRODUCT_NAME_SHORT');
UPDATE `q_main_base`.`system_properties` SET `db_Value_CISO` = 'Emerging Risk' WHERE (`db_Name` = 'PRODUCT_MODULE_MAIN_OBJECT');
UPDATE `q_main_base`.`system_properties` SET `db_Value_CISO` = 'Cyber Security Department' WHERE (`db_Name` = 'BUSINESS_DEP');
UPDATE q_main_base.system_properties SET db_Applied_To_Module = 'simp scmp stmp ctsp ciso';



ALTER TABLE `q_main_base`.`system_settings` ADD COLUMN `db_CISO` VARCHAR(500) NULL DEFAULT NULL AFTER `db_CTSP`;
UPDATE q_main_base.system_settings SET db_ciso = db_simp;
UPDATE `q_main_base`.`system_settings` SET `db_CTSP` = 'Cyber Threat Sharing Platform' WHERE (`db_Setting` = 'PRODUCT_NAME');
UPDATE `q_main_base`.`system_settings` SET `db_CISO` = 'CISO Security Analytics Platform' WHERE (`db_Setting` = 'PRODUCT_NAME');



 

ALTER TABLE `q_main_base`.`orchestrator_jobs` CHANGE COLUMN `db_Job_Last_Time_Run_Length` `db_Job_Last_Time_Run_Length` VARCHAR(45) NULL DEFAULT '0' ;



ALTER TABLE `q_main_base`.`users` 
ADD COLUMN `db_q_token_status` VARCHAR(45) NULL DEFAULT 'Deactivated' COMMENT 'Activated\nDeactivated\nReset' AFTER `db_Notifications_Enabled`,
ADD COLUMN `db_q_token_key` VARCHAR(1000) NULL AFTER `db_q_token_status`,
ADD COLUMN `db_q_token_expiration_date` DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER `db_q_token_key`,
ADD COLUMN `db_q_token_exception` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_q_token_expiration_date`;


INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('311', 'Q_TOKEN_ENABLED', '2_Factor_Authentication', 'Q-TOKEN ENABLED', 'Yes', 'No', 'No', 'No', 'No', 'No', '2022-03-14 00:03:22', 'No', 'simp scmp stmp ctsp ciso', 'List', 'Yes|No', 'Boolean', '1');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('312', 'Q_TOKEN_CUSTOMER_ID', '2_Factor_Authentication', 'Q-TOKEN CUSTOMER ID', 'Yes', '0', '0', '0', '0', '0', '2022-03-14 00:03:22', 'Please make sure to add a unique 6 digits ID for the customer. Please contact QSS Support Team.', 'No', 'simp scmp stmp ctsp ciso', 'String', '', 'Single', '2');
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('313', 'Q_TOKEN_CUSTOMER_APP_Name', '2_Factor_Authentication', 'Q-TOKEN CUSTOMER APP NAME', 'Yes', '0', '0', '0', '0', '0', '2022-02-26 13:32:53', 'Please make sure to add a short name for the customer app. Format (Customer Short name - App Short Name). Please contact QSS Support Team.', 'No', 'simp scmp stmp ctsp ciso', 'String', '', 'Single', '2');

 
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Notes`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('314', 'RESOLVED_FLAG', 'CUSTOM_FIELDS', 'RESOLVED FLAG', 'Yes', 'No', 'No', 'No', 'No', 'No', '2022-02-26 13:32:53', 'null', 'No', 'simp scmp stmp ctsp ciso', 'List', 'Yes|No', 'Boolean', '0');


ALTER TABLE `q_main_base`.`incidents` ADD COLUMN `db_Resolved_Flag` VARCHAR(5) CHARACTER SET 'latin1' NULL DEFAULT 'No' ;