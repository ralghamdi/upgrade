ALTER TABLE `q_main_base`.`users` CHANGE COLUMN `db_q_token_status` `db_q_token_status` VARCHAR(45) NULL DEFAULT 'Unenrolled' COMMENT 'Unenrolled\\nEnrolled\\nReset\nWhitelisted' ;
UPDATE q_main_base.users SET db_q_token_status = 'Unenrolled';
ALTER TABLE `q_main_base`.`users` DROP COLUMN `db_q_token_exception`;
INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('315', 'MFA_ENFORCED', 'Security_Properties', 'MFA PROTECTION ENFORCED', 'Yes', 'No', 'No', 'No', 'No', 'No', '2022-03-21 12:20:07', 'No', 'simp scmp stmp ctsp ciso', 'List', 'Yes|No', 'Boolean', '1');
UPDATE `q_main_base`.`system_properties` SET db_Group = 'MFA'  WHERE db_Group = '2_Factor_Authentication';



INSERT INTO `q_main_base`.`system_properties` (`db_id`, `db_Name`, `db_Group`, `db_Display_Text`, `db_Customizable`, `db_Value_SIMP`, `db_Value_SCMP`, `db_Value_STMP`, `db_Value_CTSP`, `db_Value_CISO`, `db_LastUpdate`, `db_Hidden`, `db_Applied_To_Module`, `db_Value_Type`, `db_List_Default_Values`, `db_Value_Selection`, `db_Group_Order`) VALUES ('316', 'SAMA_CSF_KRI_ENFORCED', 'Custom_View', 'SAMA CSF KRIs', 'Yes', 'No', 'No', 'No', 'No', 'No', '2022-03-28 10:36:43', 'No', 'simp scmp stmp ctsp ciso', 'List', 'Yes|No', 'Boolean', '1');


CREATE TABLE `sama_csf` (
  `db_id` int NOT NULL AUTO_INCREMENT,
  `db_number` int DEFAULT '0',
  `db_requirement_description` longtext,
  `db_domain_code` varchar(100) DEFAULT '-',
  `db_domain` varchar(1000) DEFAULT '-',
  `db_sub_domain_code` varchar(100) DEFAULT '-',
  `db_sub_domain` varchar(1000) DEFAULT '-',
  `db_control_number` varchar(100) DEFAULT '-',
  `db_key_risk_indicator` longtext,
  `db_kri_description` longtext,
  `db_kri_type` varchar(45) DEFAULT 'Number',
  `db_risk_appetite` int DEFAULT '0',
  `db_risk_appetite_operator` varchar(5) DEFAULT '>',
  `db_risk_tolerance` int DEFAULT '0',
  `db_risk_tolerance_operator` varchar(5) DEFAULT '>',
  `db_kri_score` int DEFAULT NULL,
  `db_del` varchar(3) DEFAULT 'No',
  `db_user_id` int DEFAULT NULL,
  `db_entry_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `db_last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_module` varchar(45) DEFAULT NULL,
  `db_area_of_improvement` longtext,
  `db_owner` varchar(100) DEFAULT '-',
  `db_target_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;




ALTER TABLE `q_main_base`.`sama_csf` ADD COLUMN `db_target_date_enabled` VARCHAR(3) NULL DEFAULT 'No' AFTER `db_target_date`;

ALTER TABLE `q_main_base`.`sla_d` 
ADD COLUMN `db_Target_Max_Age_Enabled` VARCHAR(45) NULL DEFAULT 'No' COMMENT 'Informational \\\\\\\\\\\\\\\\nLow \\\\\\\\\\\\\\\\nMedium \\\\\\\\\\\\\\\\nHigh \\\\\\\\\\\\\\\\nCritical' AFTER `db_Escalation_Recipients`,
ADD COLUMN `db_Target_Max_Age_Value` INT NULL DEFAULT '0' COMMENT 'In Seconds' AFTER `db_Target_Max_Age_Enabled`,
ADD COLUMN `db_Target_Max_Age_Unit` VARCHAR(45) NULL DEFAULT 'M' COMMENT 'M = Minuets\\\\\\\\nH = Hours\\\\\\\\nD = Days' AFTER `db_Target_Max_Age_Value`,
ADD COLUMN `db_Escalation_Max_Age_Enabled` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_Target_Max_Age_Unit`,
ADD COLUMN `db_Escalation_Max_Age_Threshold` INT NULL DEFAULT '0' AFTER `db_Escalation_Max_Age_Enabled`;

ALTER TABLE `q_main_base`.`incidents` 
ADD COLUMN `db_Max_Age_Date` DATETIME NULL DEFAULT NULL AFTER `db_Resolved_Flag`,
ADD COLUMN `db_Max_Age_Duration` INT NULL DEFAULT '0' AFTER `db_Max_Age_Date`,
ADD COLUMN `db_Max_Age_Status` VARCHAR(45) NULL DEFAULT 'Not Started' AFTER `db_Max_Age_Duration`,
ADD COLUMN `db_Max_Age_SLA_Violated` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_Max_Age_Status`,
ADD COLUMN `db_Max_Age_Escalation_Email_Sent` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_Max_Age_SLA_Violated`,
ADD COLUMN `db_Max_Age_SLA_Warning_Email_Sent` VARCHAR(5) NULL DEFAULT 'No' AFTER `db_Max_Age_Escalation_Email_Sent`;